void loadringmacro();
void scoreringmacro();
void scoreringmacroto();
void armdown();