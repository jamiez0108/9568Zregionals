void initializeDisplayTask();
void displayCoordinatesAndBattery(void* param);